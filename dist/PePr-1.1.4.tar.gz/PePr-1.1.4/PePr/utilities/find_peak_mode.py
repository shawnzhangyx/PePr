#!/user/bin/env python
# use this script to find the mode of a peak. 
# Input: peak file, read file and format(bed,bam,sam)
# Output: peak file with additional column denoting the peak_mode
### usage: python find_peak_mode.py Peaks_file read_file file_format shift_size
# Created By Yanxiao Zhang, 5/19/2016
############################################


def process_peak_file(



def main(argv):
    peak_file = 

